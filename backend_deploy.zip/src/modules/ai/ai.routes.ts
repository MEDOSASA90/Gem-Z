import express from 'express';
import { verifyToken as authenticate } from '../../core/middlewares/auth.middleware';
import { generatePlan, getSavedPlans } from './ai.controller';

const router = express.Router();

router.post('/generate', authenticate as any, generatePlan as any);
router.get('/plans', authenticate as any, getSavedPlans as any);

export default router;
