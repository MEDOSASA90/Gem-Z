import { Request, Response } from 'express';
import { AuthRequest } from '../../core/middlewares/auth.middleware';
import { AIService } from '../../services/ai.service';
import { db } from '../../core/database/db';

export const generatePlan = async (req: AuthRequest, res: Response): Promise<any> => {
    try {
        const userId = req.user?.userId as string; // Usually the trainer's ID
        const { traineeName, age, weight, height, goal, fitnessLevel, allergies, limitations } = req.body;

        if (!traineeName || !age || !weight || !goal) {
            return res.status(400).json({ success: false, message: 'Missing required trainee stats.' });
        }

        const profile = { traineeName, age, weight, height, goal, fitnessLevel, allergies, limitations };
        const result = await AIService.generateComprehensivePlan(profile, userId);

        return res.status(200).json({ success: true, planData: result.plan, planId: result.planId });
    } catch (error: any) {
        console.error('[AIController generatePlan]', error);
        return res.status(500).json({ success: false, message: error.message || 'Error generating AI plan.' });
    }
};

export const getSavedPlans = async (req: AuthRequest, res: Response): Promise<any> => {
    try {
        const userId = req.user?.userId as string;
        const { rows } = await db.query(`SELECT * FROM ai_generated_plans WHERE trainer_id = $1 ORDER BY created_at DESC`, [userId]);
        return res.status(200).json({ success: true, count: rows.length, plans: rows });
    } catch (error) {
        return res.status(500).json({ success: false, message: 'Failed to fetch saved AI plans.' });
    }
};
