import { Response } from 'express';
import z from 'zod';
import { AuthRequest } from '../../core/middlewares/auth.middleware';
import { db } from '../../core/database/db';

export const getGymStats = async (req: AuthRequest, res: Response) => {
    try {
        const userId = req.user?.userId;
        if (!userId) return res.status(401).json({ error: 'Unauthorized Gym Access' });

        // Resolve Gym ID from User ID (Owner)
        const gymDbRes = await db.query('SELECT id FROM gyms WHERE owner_user_id = $1', [userId]);
        if (gymDbRes.rowCount === 0) return res.status(404).json({ error: 'Gym profile not found' });
        const gymId = gymDbRes.rows[0].id;

        // Get Wallet Balances for this gym
        const walletQuery = await db.query(
            `SELECT available_bal, pending_bal FROM wallets WHERE owner_id = $1 AND owner_type = 'gym'`,
            [gymId]
        );
        const availableBal = walletQuery.rowCount && walletQuery.rowCount > 0 ? parseFloat(walletQuery.rows[0].available_bal) : 0;
        const pendingBal = walletQuery.rowCount && walletQuery.rowCount > 0 ? parseFloat(walletQuery.rows[0].pending_bal) : 0;

        // Fetch Active Subscribers
        const subscribersQuery = await db.query(`
            SELECT gs.id, gs.starts_at as start_date, gs.expires_at as end_date, u.full_name as trainee_name
            FROM gym_subscriptions gs
            JOIN users u ON gs.trainee_id = u.id
            WHERE gs.branch_id IN (SELECT id FROM gym_branches WHERE gym_id = $1)
            AND gs.status = 'active'
        `, [gymId]);
        
        const subscribers = subscribersQuery.rows;
        const totalMembers = subscribers.length;

        // Fetch Live Visits (Check-Ins / Check-Outs for today)
        const visitsQuery = await db.query(`
            SELECT gv.id, gv.checked_in_at as check_in_time, gv.checked_out_at as check_out_time, u.full_name as trainee_name
            FROM attendance_logs gv
            JOIN users u ON gv.trainee_id = u.id
            WHERE gv.branch_id IN (SELECT id FROM gym_branches WHERE gym_id = $1)
            ORDER BY gv.checked_in_at DESC
            LIMIT 50
        `, [gymId]);
        const visits = visitsQuery.rows;

        return res.status(200).json({
            success: true,
            data: {
                availableBal,
                pendingBal,
                totalMembers,
                subscribers,
                visits
            }
        });

    } catch (error) {
        console.error('[GymController] getGymStats Error:', error);
        return res.status(500).json({ error: 'Internal Server Error' });
    }
};

export const buyDailyPass = async (req: AuthRequest, res: Response) => {
    const client = await db.connect();
    try {
        const traineeId = req.user?.userId;
        const { gymId, price } = req.body;

        if (!gymId || !price) return res.status(400).json({ success: false, message: 'Missing gym ID or price' });

        await client.query('BEGIN');

        // Generate unique QR
        const qrCode = `PASS_${Date.now()}_${Math.random().toString(36).substring(7).toUpperCase()}`;

        // Expiry = 24 hours from now
        const expiresAt = new Date();
        expiresAt.setHours(expiresAt.getHours() + 24);

        const { rows } = await client.query(`
            INSERT INTO gym_daily_passes (gym_id, trainee_id, price_paid, qr_code, expires_at)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING *;
        `, [gymId, traineeId, price, qrCode, expiresAt]);

        // Create financial transaction for the Gym (20% platform fee)
        const platformFee = Number(price) * 0.20;
        const netAmount = Number(price) - platformFee;

        await client.query(`
            INSERT INTO financial_transactions (user_id, buyer_id, amount, platform_fee, net_amount, type)
            VALUES ($1, $2, $3, $4, $5, 'GYM_PASS')
        `, [gymId, traineeId, price, platformFee, netAmount]);

        await client.query('COMMIT');
        return res.status(201).json({ success: true, pass: rows[0], message: 'Pass purchased successfully' });
    } catch (error: any) {
        await client.query('ROLLBACK');
        console.error('[GymController] buyDailyPass:', error);
        return res.status(500).json({ success: false, message: 'Failed to buy daily pass' });
    } finally {
        client.release();
    }
};

export const scanDailyPass = async (req: AuthRequest, res: Response) => {
    try {
        const scannerUserId = req.user?.userId; // This is the Gym Owner's ID
        const { qrCode } = req.body;

        if (!qrCode) return res.status(400).json({ success: false, message: 'Missing QR Code' });

        // Resolve Gym ID from scanner user ID
        const gymRes = await db.query('SELECT user_id FROM gyms WHERE user_id = $1', [scannerUserId]);
        const gymId = gymRes.rowCount && gymRes.rowCount > 0 ? gymRes.rows[0].user_id : scannerUserId;

        // Verify Pass
        const passRes = await db.query(`
            SELECT * FROM gym_daily_passes
            WHERE qr_code = $1 AND gym_id = $2
        `, [qrCode, gymId]);

        if (passRes.rowCount === 0) {
            return res.status(404).json({ success: false, message: 'Invalid Pass for this Gym' });
        }

        const pass = passRes.rows[0];

        if (pass.is_used) {
            return res.status(400).json({ success: false, message: 'Pass has already been used' });
        }

        if (new Date() > new Date(pass.expires_at)) {
            return res.status(400).json({ success: false, message: 'Pass has expired' });
        }

        // Mark as used
        await db.query(`
            UPDATE gym_daily_passes
            SET is_used = TRUE, scanned_at = NOW()
            WHERE id = $1
        `, [pass.id]);

        return res.status(200).json({ success: true, message: 'Access Granted! Pass consumed.' });

    } catch (error) {
        console.error('[GymController] scanDailyPass:', error);
        return res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

export const getTraineePasses = async (req: AuthRequest, res: Response) => {
    try {
        const traineeId = req.user?.userId;
        const { rows } = await db.query(`
            SELECT p.*, g.gym_name 
            FROM gym_daily_passes p
            JOIN gyms g ON p.gym_id = g.user_id
            WHERE p.trainee_id = $1
            ORDER BY p.created_at DESC
        `, [traineeId]);
        
        return res.status(200).json({ success: true, passes: rows });
    } catch (error) {
        console.error('[GymController] getTraineePasses:', error);
        return res.status(500).json({ success: false, message: 'Server error' });
    }
};
